3)])
# cv2.imshow('char2', final[(j*3)+1])
# cv2.imshow('char3', final[(j*3)+2]) 