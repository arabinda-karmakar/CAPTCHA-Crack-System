import cv2
import numpy as np

#https://www.freedomvc.com/index.php/2022/01/17/basic-background-remover-with-opencv/

def bgremove3(myimage):
    # BG Remover 3
    myimage_hsv = cv2.cvtColor(myimage, cv2.COLOR_BGR2HSV)
     
    #Take S and remove any value that is less than half
    s = myimage_hsv[:,:,1]
    s = np.where(s < 127, 0, 1) # Any value below 127 will be excluded
 
 
    # Combine our two masks based on S and V into a single "Foreground"
    foreground = np.where(s > 0, 1, 0).astype(np.uint8)  #Casting back into 8bit integer
 
    background = np.where(foreground==0,255,0).astype(np.uint8) # Invert foreground to get background in uint8
    background = cv2.cvtColor(background, cv2.COLOR_GRAY2BGR)  # Convert background back into BGR space
    foreground=cv2.bitwise_and(myimage,myimage,mask=foreground) # Apply our foreground map to original image
    finalimage = background+foreground # Combine foreground and background
 
    return finalimage
def bgremove4(myimage):
    # BG Remover 3
    myimage_hsv = cv2.cvtColor(myimage, cv2.COLOR_BGR2HSV)
    # We increase the brightness of the image and then mod by 255
    v = myimage_hsv[:,:,2] 
    v = np.where(v > 170, 0, 1)  # Any value above 127 will be part of our mask
 
    # Combine our two masks based on S and V into a single "Foreground"
    foreground = np.where(v > 0, 1, 0).astype(np.uint8)  #Casting back into 8bit integer
 
    background = np.where(foreground==0,255,0).astype(np.uint8) # Invert foreground to get background in uint8
    background = cv2.cvtColor(background, cv2.COLOR_GRAY2BGR)  # Convert background back into BGR space
    foreground=cv2.bitwise_and(myimage,myimage,mask=foreground) # Apply our foreground map to original image
    finalimage = background+foreground # Combine foreground and background
 
    return finalimage

image = [ cv2.imread(f"./train/{i}.png") for i in range( 2000 ) ]	
hsvImage =[ cv2.cvtColor(image[i], cv2.COLOR_BGR2HSV) for i in range(2000)]
image_class = cv2.imread("C:/Users/VINAY AGRAWAL/Desktop/ml assgn 3/assn3/assn3/reference/OMEGA.png")
rot = cv2.rotate(image_class, cv2.cv2.ROTATE_90_CLOCKWISE)
cv2.imshow("a", rot)
final = []
final1 = []
c = 0
# bgremove3(image)
for i in range(200):
        a = bgremove3(image[i])
        y = bgremove4(a)
        grayImage = cv2.cvtColor(y, cv2.COLOR_BGR2GRAY)  
        thresh = 128
        img_binary = cv2.threshold(grayImage, thresh, 255, cv2.THRESH_BINARY)[1]
        final1.append(img_binary)
        z = np.average(img_binary,axis=0)
        markup_pt = []
        for p in range(500):
            if(z[p] < 255 and z[p-1] == 255 and p!= 0):
                markup_pt.append(p)
            if(p!= 0 and z[p-1] < 255 and z[p] == 255):
                markup_pt.append(p)
        print(">>>>>>>>>>.",markup_pt,i)
        char1 = img_binary[0:150,markup_pt[0]:markup_pt[1]]
        char2 = img_binary[0:150,markup_pt[2]:markup_pt[3]]
        char3 = img_binary[0:150,markup_pt[4]:markup_pt[5]]
        final.append(char1)
        final.append(char2)
        final.append(char3)

j = 199
cv2.imshow('Original image',image[j])
cv2.imshow('HSV image', hsvImage[j])
cv2.imshow('eroded', final1[j]) 
cv2.imshow('char1', final[(j*3)])
cv2.imshow('char2', final[(j*3)+1])
cv2.imshow('char3', final[(j*3)+2]) 



cv2.waitKey(0)
cv2.destroyAllWindows()