) ]	
# hsvImage =[ cv2.cvtColor(image[i], cv2.COLOR_BGR2HSV) for i in range